import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory store for simulated logs and playbooks
  const logs: any[] = [
    { id: "init_1", timestamp: new Date(Date.now() - 120000).toISOString(), type: "SHADOW_AI", message: "Initial neural handshake established with Blue AI Gateway", severity: "low" },
    { id: "init_2", timestamp: new Date(Date.now() - 300000).toISOString(), type: "THREAT", message: "Geographic anomaly detected: User 'v.affiliate' ping from UNKNOWN_NODE", severity: "medium" },
    { id: "init_3", timestamp: new Date(Date.now() - 600000).toISOString(), type: "SYSTEM", message: "Post-reboot integrity check complete. All nodes verified.", severity: "low" }
  ];
  const playbooks: any[] = [
    {
      id: "pb_01",
      attackType: "Advanced Persistent Threat (Neural)",
      content: "PATTERN: Multi-stage exfiltration via non-standard ports following neural bypass attempt. DETECTION: Correlate atypical latency with egress spikes. RESPONSE: Rotate node orchestration keys and isolate infected VLAN. SCRIPTD: neural_harden_v2.sh",
      timestamp: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: "pb_02",
      attackType: "Model Poisoning Detection",
      content: "PATTERN: Subtle drift in classification weights detected during shadow training. VECTOR: Adversarial prompt injection targeting bias thresholds. RESPONSE: Roll back to checkpoint SB_92.4; initiate full weights audit; increase prompt sanitization density.",
      timestamp: new Date(Date.now() - 14400000).toISOString()
    },
    {
      id: "pb_03",
      attackType: "Privileged Access Escalation",
      content: "PATTERN: Rapid credential usage across geographically distinct nodes using identical session tokens. RESPONSE: Force global MFA re-verification; invalidate all active OIDC tokens for the 'privileged' role; lock communication hub access.",
      timestamp: new Date(Date.now() - 86400000).toISOString()
    }
  ];
  const vulnerabilities: any[] = [
    { id: "CVE-2024-1234", description: "Remote Code Execution in Web Gateway", severity: "critical", status: "open", affected: "Internal Proxy" },
    { id: "CVE-2024-5678", description: "SQL Injection in Auth Service", severity: "high", status: "patching", affected: "User Database" },
    { id: "CVE-2023-9021", description: "Outdated OpenSSL version", severity: "medium", status: "open", affected: "Network Nodes" },
    { id: "CVE-2024-1122", description: "Broken Access Control in API", severity: "high", status: "verified", affected: "API Gateway" },
  ];
  const insiderThreats: any[] = [
    { id: 1, name: "Arjun Mehta", department: "Engineering", riskScore: 24, lastAction: "Code export", location: "Mumbai, IN" },
    { id: 2, name: "Priya Sharma", department: "Finance", riskScore: 88, lastAction: "Sensitive data paste", location: "Bangalore, IN" },
    { id: 3, name: "David Wilson", department: "HR", riskScore: 12, lastAction: "Login", location: "London, UK" },
    { id: 4, name: "Sanjay Rao", department: "IT Support", riskScore: 65, lastAction: "Credential access", location: "Delhi, IN" },
  ];

  // API Routes
  app.get("/api/vulnerabilities", (req, res) => {
    console.log("API: vulnerabilities hit");
    res.json(vulnerabilities);
  });

  app.get("/api/system-health", (req, res) => {
    console.log("API: system-health hit");
    res.json({
      serverStatus: "operational",
      networkHealth: 98,
      apiIntegrations: [
        { name: "Firewall-X", status: "connected" },
        { name: "SIEM-Nexus", status: "connected" },
        { name: "IDS-Sentinel", status: "degraded" }
      ],
      uptime: "342d 12h 45m"
    });
  });

  app.get("/api/logs", (req, res) => {
    console.log("API: logs hit");
    res.json(logs.slice(-50).reverse());
  });

  app.post("/api/logs", (req, res) => {
    console.log("API: logs POST hit");
    const log = {
      id: Date.now() + Math.random(),
      timestamp: new Date().toISOString(),
      ...req.body,
    };
    logs.push(log);
    if (logs.length > 500) logs.shift();
    res.status(201).json(log);
  });

  app.get("/api/playbooks", (req, res) => {
    console.log("API: playbooks hit");
    res.json(playbooks);
  });

  app.post("/api/playbooks", (req, res) => {
    console.log("API: playbooks POST hit");
    const pb = { id: Date.now(), ...req.body };
    playbooks.push(pb);
    if (playbooks.length > 20) playbooks.shift();
    res.json(pb);
  });

  app.get("/api/threats", (req, res) => {
    console.log("API: threats hit");
    res.json(insiderThreats);
  });

  app.post("/api/update-risk", (req, res) => {
    console.log("API: update-risk POST hit");
    const { userId, scoreIncrement } = req.body;
    const threat = insiderThreats.find(t => t.id === userId);
    if (threat) {
      threat.riskScore = Math.min(100, Math.max(0, threat.riskScore + scoreIncrement));
      threat.lastAction = "Anomalously high activity";
    }
    res.json({ success: true, threat });
  });

  // Catch-all for API routes before Vite/SPA fallback
  app.all("/api/*", (req, res) => {
    console.warn(`API: 404 hit for ${req.method} ${req.url}`);
    res.status(404).json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // Background mock log generator (Reflecting Layers 1-8)
  const DUMMY_LOGS = [
    { type: "RED_AI", source: "Caldera", layer: 1, message: "Simulated Lateral Movement: Admin IPC$ share scanned", severity: "medium" },
    { type: "RED_AI", source: "Metasploit", layer: 1, message: "Reverse TCP handler established on session #3", severity: "high" },
    { type: "COLLECTOR", source: "Wazuh Agent", layer: 2, message: "Integrity check failed: /usr/bin/sudo checksum mismatch", severity: "high" },
    { type: "NETWORK", source: "Zeek", layer: 3, message: "DNS Tunneling pattern detected: Anomalous query density to .xyz domain", severity: "medium" },
    { type: "DETECTION", source: "Elastic Security", layer: 3, message: "ML Job: Unusual login time for user 'svc_prod_bak'", severity: "low" },
    { type: "PROCESSING", source: "NORMALIZER", layer: 4, message: "Normalized schema: Field 'src_ip' mapped from zeek_id", severity: "info" },
    { type: "INTELLIGENCE", source: "GEMINI_L5", layer: 5, message: "Ollama/DeepSeek: Deep Analysis correlation - Multi-stage exfiltration detected", severity: "high" },
    { type: "DECISION", source: "BLOCKER", layer: 6, message: "Decision L6: Enforce MFA for target account", severity: "warning" },
    { type: "STORAGE", source: "FAISS_VEC", layer: 7, message: "Indexed: T1003 Credential Dumping pattern learned", severity: "info" },
    { type: "API", source: "CONTROL_HUB", layer: 8, message: "Status: Layer synchronization stable", severity: "low" },
    { type: "SYSTEM", source: "Wazuh Manager", layer: 3, message: "Rule 5716 triggered: SSH login attempt from blocked IP", severity: "medium" },
    { type: "SHADOW_AI", source: "Blue AI Controller", layer: 5, message: "Ollama/DeepSeek: Prompt neutralized - SQL injection intent detected", severity: "high" },
    { type: "RESPONSE", source: "FastAPI Middleware", layer: 6, message: "Auto-Containment: Node isolated in VLAN 402", severity: "critical" },
    { type: "STORAGE", source: "Vector DB (FAISS)", layer: 7, message: "Embedding indexed: Pattern 'Neural Bypass v4' added to memory", severity: "low" },
  ];

  const INITIAL_PLAYBOOKS = [
    { 
      id: "PB-7721", 
      attackType: "Brute Force", 
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      content: "Intelligence L5 Analysis:\nConfidence: 0.98\nExplanation: Detected rapid sequence of failed authentication attempts targeting administrative consoles across multiple endpoints.\nSuggestion: Implement global IP ban for 24h and force MFA re-authentication."
    },
    { 
      id: "PB-9910", 
      attackType: "SQL Injection", 
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      content: "Intelligence L5 Analysis:\nConfidence: 0.95\nExplanation: Abnormal character frequencies detected in URL parameters matching known SQL injection payloads.\nSuggestion: Scrub inbound queries via WAF and update ORM sanitization rules."
    }
  ];

  app.get("/api/playbooks", (req, res) => {
    console.log(`[API] GET /api/playbooks requested`);
    res.json(INITIAL_PLAYBOOKS);
  });

  setInterval(() => {
    const randomLog = DUMMY_LOGS[Math.floor(Math.random() * DUMMY_LOGS.length)];
    logs.push({
      id: Date.now() + Math.random(),
      timestamp: new Date().toISOString(),
      ...randomLog
    });
    if (logs.length > 500) logs.shift();
  }, 8000);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
