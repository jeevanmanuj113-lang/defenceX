import React, { useState, useEffect, useCallback } from "react";
import { 
  Shield, 
  Terminal, 
  Activity, 
  AlertTriangle, 
  Eye, 
  EyeOff,
  UserX,
  Play, 
  Zap, 
  Network, 
  Lock,
  Search,
  RefreshCw,
  Cpu,
  Brain,
  XCircle,
  Database,
  LayoutDashboard,
  Bug,
  BookOpen,
  ClipboardList,
  Settings,
  ChevronRight,
  ShieldCheck,
  Target,
  Filter,
  History,
  Circle
} from "lucide-react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from "recharts";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "./lib/utils";
import * as gemini from "./services/geminiService";
import { AuthPage } from "./components/AuthPage";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

// Mock Data for Charts
const threatData = [
  { time: "00:00", threats: 12, risk: 24 },
  { time: "04:00", threats: 18, risk: 36 },
  { time: "08:00", threats: 45, risk: 65 },
  { time: "12:00", threats: 32, risk: 58 },
  { time: "16:00", threats: 56, risk: 82 },
  { time: "20:00", threats: 28, risk: 45 },
  { time: "23:59", threats: 15, risk: 30 },
];

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"dashboard" | "shadow-ai" | "vulnerabilities" | "threats" | "simulation" | "blue-ai" | "shadow-brain" | "compliance" | "health" | "reports" | "settings" | "architecture">("dashboard");
  const [logs, setLogs] = useState<any[]>([]);
  const [insiderThreats, setInsiderThreats] = useState<any[]>([]);
  const [playbooks, setPlaybooks] = useState<any[]>([]);
  const [vulnerabilities, setVulnerabilities] = useState<any[]>([]);
  const [systemHealth, setSystemHealth] = useState<any>(null);
  const [intelligenceReports, setIntelligenceReports] = useState<any[]>([]);
  const [analyzingThreatId, setAnalyzingThreatId] = useState<string | null>(null);
  const [interceptInput, setInterceptInput] = useState("");
  const [interceptResult, setInterceptResult] = useState<any>(null);
  const [isIntercepting, setIsIntercepting] = useState(false);
  const [simulation, setSimulation] = useState<any>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [playbook, setPlaybook] = useState<string | null>(null);
  
  // Dynamic metrics
  const [metrics, setMetrics] = useState({
    interception: 942,
    prevention: 4.2,
    latency: 14,
    nodeLoads: [42, 5, 88, 0]
  });

  const fetchLogs = useCallback(async () => {
    try {
      const res = await fetch("/api/logs");
      if (!res.ok) throw new Error("Log fetch failed");
      const data = await res.json();
      setLogs(data);
    } catch (e) {
      console.warn("Failed to fetch logs:", e);
    }
    
    try {
      const pbRes = await fetch("/api/playbooks");
      if (pbRes.ok) {
        const pbData = await pbRes.json();
        setPlaybooks(pbData);
      }
    } catch (e) {
      console.warn("Failed to fetch playbooks:", e);
    }
  }, []);

  const handleIntelligenceAnalysis = async (threat: any) => {
    setAnalyzingThreatId(threat.id);
    try {
      const alert = {
        type: threat.lastAction || "Suspicious Activity",
        source: threat.name,
        severity: threat.riskScore || 50,
        timestamp: new Date().toISOString()
      };
      
      const analysis = await gemini.intelligenceAnalysis(alert, logs.slice(0, 10));
      
      const report = {
        threatId: threat.id,
        analysis,
        timestamp: new Date().toISOString()
      };
      
      setIntelligenceReports(prev => [report, ...prev]);
      setActiveTab("shadow-brain"); // Redirect to show the "intelligence" hub
    } catch (e) {
      console.error("Intelligence Layer Failure:", e);
    } finally {
      setAnalyzingThreatId(null);
    }
  };

  const fetchThreats = useCallback(async (retries = 3) => {
    try {
      const res = await fetch("/api/threats");
      if (!res.ok) throw new Error(`Threat fetch failed: ${res.status}`);
      
      const contentType = res.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await res.text();
        throw new Error(`Expected JSON but got ${contentType || "unknown"}. First 100 bytes: ${text.slice(0, 100)}`);
      }

      const data = await res.json();
      setInsiderThreats(data);
    } catch (e) {
      if (retries > 0) {
        console.warn(`Threat intelligence fetch failed, retrying... (${retries} left). Error: ${e instanceof Error ? e.message : String(e)}`);
        setTimeout(() => fetchThreats(retries - 1), 1000);
      } else {
        console.error("Threat Intelligence Link Failure:", e);
      }
    }
  }, []);

  const fetchExtraData = useCallback(async () => {
    try {
      const vRes = await fetch("/api/vulnerabilities");
      if (vRes.ok) {
        const vData = await vRes.json();
        setVulnerabilities(vData);
      }

      const hRes = await fetch("/api/system-health");
      if (hRes.ok) {
        const hData = await hRes.json();
        setSystemHealth(hData);
      }

      const pRes = await fetch("/api/playbooks");
      if (pRes.ok) {
        const pData = await pRes.json();
        setPlaybooks(pData);
      }
    } catch (e) {
      console.warn("Supplementary Data Sync Failed:", e);
    }
  }, []);

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem("defend_x_user");
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        localStorage.removeItem("defend_x_user");
      }
    }

    fetchLogs();
    fetchThreats(3);
    fetchExtraData();

    const interval = setInterval(() => {
      fetchLogs();
      fetchThreats(0); // No retry in interval to avoid stacking
      fetchExtraData();
      // Randomly update metrics for "alive" feel
      setMetrics(prev => ({
        interception: Math.max(800, prev.interception + Math.floor(Math.random() * 21) - 10),
        prevention: Number((prev.prevention + (Math.random() * 0.05)).toFixed(2)),
        latency: Math.max(8, prev.latency + Math.floor(Math.random() * 5) - 2),
        nodeLoads: prev.nodeLoads.map(l => Math.min(100, Math.max(0, l + Math.floor(Math.random() * 7) - 3)))
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, [fetchLogs, fetchThreats, fetchExtraData]);

  const addLog = async (type: string, message: string, severity: "low" | "medium" | "high" | "critical") => {
    try {
      const res = await fetch("/api/logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, message, severity }),
      });
      if (res.ok) fetchLogs();
    } catch (e) {
      console.error("Failed to append log:", e);
    }
  };

  const handleIntercept = async () => {
    if (!interceptInput.trim()) return;
    setIsIntercepting(true);
    setInterceptResult(null);
    
    const result = await gemini.analyzePrompt(interceptInput);
    setInterceptResult(result);
    setIsIntercepting(false);

    if (result?.action && result.action !== "ALLOW") {
      addLog("SHADOW_AI", `Prompt ${result.action}: ${result.classification.join(", ")}`, result.action === "BLOCK" ? "high" : "medium");
      if (result.riskScore > 50) {
        fetch("/api/update-risk", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: 2, scoreIncrement: 5 }),
        });
        fetchThreats(0);
      }
    }
  };

  const handleSimulate = async () => {
    setIsSimulating(true);
    setPlaybook(null);
    const result = await gemini.simulateAttack();
    setSimulation(result);
    setIsSimulating(false);
    
    if (result) {
      addLog("RED_AI", `Simulated attack launched: ${result.attackType}`, "critical");
      const pbText = await gemini.generateDefensivePlaybook(result.attackType, JSON.stringify(result.steps));
      setPlaybook(pbText);
      addLog("BLUE_AI", `Playbook generated for ${result.attackType}`, "medium");
      
      // Save playbook to backend
      await fetch("/api/playbooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ attackType: result.attackType, content: pbText, timestamp: new Date().toISOString() }),
      });
      fetchLogs();
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("defend_x_user");
    setUser(null);
  };

  const handleGeneratePDF = (type: string) => {
    const doc = new jsPDF();
    const timestamp = new Date().toLocaleString();
    const appName = "Defend X";
    
    // Header
    doc.setFillColor(17, 17, 19); // card-bg
    doc.rect(0, 0, 210, 40, "F");
    
    doc.setTextColor(157, 80, 255); // shadow-ai
    doc.setFontSize(24);
    doc.text(appName, 15, 25);
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(10);
    doc.text(`${type.toUpperCase()} SECURITY REPORT`, 15, 33);
    doc.text(timestamp, 150, 25);

    // AI Insight Section (Shadow AI Brain Context)
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.text("Autonomous Neural Context (Shadow AI Brain)", 15, 55);
    doc.setFontSize(10);
    doc.text([
      "The Shadow AI Brain has processed over 1.2M security events in the last 24h.",
      "Intelligence refinement suggests a 15% increase in phishing complexity from ASIA_CENTRAL.",
      "Defensive playbooks have been automatically synchronized across all H100 GPU nodes.",
      "- Detection Consistency: 99.8%",
      "- AI Risk Score Mitigation: +4.2%",
    ], 15, 65);

    // Add Table for Logs if Technical
    if (type === "Technical") {
      const tableRows = logs.slice(0, 15).map(l => [
        new Date(l.timestamp).toLocaleTimeString(),
        l.type.toUpperCase(),
        l.severity.toUpperCase(),
        l.message
      ]);
      autoTable(doc, {
        startY: 100,
        head: [['Time', 'Type', 'Severity', 'Event Details']],
        body: tableRows,
        theme: 'striped',
        headStyles: { fillColor: [157, 80, 255] }
      });
    } else {
        doc.text("Report Summary Section:", 15, 100);
        doc.text("All systems currently operating within standard security thresholds.", 15, 110);
        doc.text("No unauthorized entry into DPDPA Privacy Vaults recorded.", 15, 120);
    }

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(`Generated by Defend X Neural Defense Platform. Authorized agent: ${user?.name || 'System'}`, 105, 285, { align: "center" });

    doc.save(`${appName}_${type}_Report_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  if (!user) {
    return <AuthPage onLogin={setUser} />;
  }

  return (
    <div className="flex flex-col h-screen w-full bg-bg text-text-main font-sans selection:bg-shadow-ai/30 overflow-hidden subtle-grid">
      {/* Header */}
      <header className="h-16 shrink-0 border-b border-border-main bg-bg/50 backdrop-blur-md flex items-center justify-between px-8 z-50">
        <div className="flex items-center gap-4">
          <div className="w-9 h-9 bg-shadow-ai rounded-lg flex items-center justify-center shadow-lg shadow-shadow-ai/20">
            <Shield className="text-white w-5 h-5" />
          </div>
          <div className="font-black text-xl tracking-tighter uppercase font-sans">
            DEFEND<span className="text-shadow-ai text-3xl italic">.</span>X
          </div>
        </div>

        <div className="flex items-center gap-12">
          <div className="flex gap-10 items-center">
            <div className="flex items-center gap-4 mr-4">
              <div className="w-8 h-8 rounded-full bg-shadow-ai/10 border border-shadow-ai/20 flex items-center justify-center text-[10px] font-bold text-shadow-ai">
                {user.name?.[0].toUpperCase() || "A"}
              </div>
              <div className="hidden md:block">
                <div className="text-[11px] font-bold text-text-main tracking-tight leading-none">{user.name}</div>
                <div className="text-[9px] text-text-dim uppercase tracking-[0.2em] mt-1 italic font-medium">Level 4 Agent</div>
              </div>
            </div>
            <HeaderStat label="Interception" value={`${metrics.interception} req/s`} color="text-shadow-ai" />
            <HeaderStat label="Mitigation" value={`$${metrics.prevention}M`} color="text-success" />
          </div>
          <div className="h-8 w-px bg-border-main/50 mx-2" />
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 bg-red-ai/5 hover:bg-red-ai/10 px-4 py-2 rounded-lg text-[10px] font-bold tracking-widest transition-all border border-red-ai/20 text-red-ai hover:border-red-ai/40"
          >
            <XCircle className="w-3.5 h-3.5" />
            TERMINATE
          </button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Navigation */}
        <aside className="w-[260px] border-r border-border-main flex flex-col p-8 gap-10 shrink-0 bg-bg">
          <nav className="space-y-10">
            <NavGroup title="Defense Architecture">
              <NavItem 
                active={activeTab === "dashboard"} 
                onClick={() => setActiveTab("dashboard")} 
                label="Security Monitor" 
                icon={<LayoutDashboard size={16} />} 
              />
              <NavItem 
                active={activeTab === "shadow-ai"} 
                onClick={() => setActiveTab("shadow-ai")} 
                label="Shadow AI Interceptor" 
                icon={<Eye size={16} />} 
              />
              <NavItem 
                active={activeTab === "vulnerabilities"} 
                onClick={() => setActiveTab("vulnerabilities")} 
                label="Vulnerabilities" 
                icon={<Search size={16} />} 
              />
              <NavItem 
                active={activeTab === "threats"} 
                onClick={() => setActiveTab("threats")} 
                label="Threat Hunting" 
                icon={<Bug size={16} />} 
              />
            </NavGroup>

            <NavGroup title="AI Engines">
              <NavItem 
                active={activeTab === "simulation"} 
                onClick={() => setActiveTab("simulation")} 
                label="Red AI Simulation" 
                icon={<Cpu size={16} />} 
              />
              <NavItem 
                active={activeTab === "blue-ai"} 
                onClick={() => setActiveTab("blue-ai")} 
                label="Blue AI Classifier" 
                icon={<ShieldCheck size={16} />} 
              />
              <NavItem 
                active={activeTab === "shadow-brain"} 
                onClick={() => setActiveTab("shadow-brain")} 
                label="Shadow AI Brain" 
                icon={<Zap size={16} />} 
              />
            </NavGroup>

            <NavGroup title="Enterprise">
              <NavItem 
                active={activeTab === "compliance"} 
                onClick={() => setActiveTab("compliance")} 
                label="Compliance Audit" 
                icon={<ClipboardList size={16} />} 
              />
              <NavItem 
                active={activeTab === "health"} 
                onClick={() => setActiveTab("health")} 
                label="System Health" 
                icon={<Activity size={16} />} 
              />
              <NavItem 
                active={activeTab === "reports"} 
                onClick={() => setActiveTab("reports")} 
                label="Reports & Export" 
                icon={<BookOpen size={16} />} 
              />
              <NavItem 
                active={activeTab === "architecture"} 
                onClick={() => setActiveTab("architecture")} 
                label="Core Architecture" 
                icon={<Cpu size={16} />} 
              />
              <NavItem 
                active={activeTab === "settings"} 
                onClick={() => setActiveTab("settings")} 
                label="SOC Settings" 
                icon={<Settings size={16} />} 
              />
            </NavGroup>
          </nav>
        </aside>

        {/* Center Content Viewport */}
        <section className="flex-1 flex flex-col border-r border-border-main bg-bg overflow-hidden relative">
          <header className="h-14 border-b border-border-main flex items-center justify-between px-6 shrink-0 bg-card-bg/20">
            <h2 className="text-[12px] font-bold uppercase tracking-widest flex items-center gap-2">
              <span className="text-shadow-ai">●</span> {activeTab.replace('-', ' ').toUpperCase()} VIEWPORT
            </h2>
            <div className="text-[10px] text-text-dim font-mono flex items-center gap-4">
              <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" /> CLOUD_SYNC_OK</span>
              <span>Uptime: 99.99%</span>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto p-6 scrollbar-hide">
            <AnimatePresence mode="wait">
              {activeTab === "dashboard" && (
                <motion.div key="db" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                  {/* Top Stats - Section 1: Security Overview */}
                  <div className="grid grid-cols-5 gap-4">
                    <DashboardStat label="Total Threats (Today)" value="142" color="text-shadow-ai" />
                    <DashboardStat label="Critical Alerts" value={String(logs.filter(l => l.severity === 'critical').length).padStart(2, '0')} color="text-red-ai" />
                    <DashboardStat 
                      label="AI Risk Score" 
                      value={`${Math.round(insiderThreats.reduce((acc, t) => acc + t.riskScore, 0) / (insiderThreats.length || 1))}%`} 
                      color="text-warning" 
                    />
                    <DashboardStat label="Ongoing Attacks" value="03" color="text-red-ai" />
                    <DashboardStat label="System Status" value="SECURE" color="text-success" />
                  </div>

                  {/* Section 2: Real-Time Threat Monitoring & Risk Scoring */}
                  <div className="grid grid-cols-3 gap-6">
                    <div className="col-span-2 bg-card-bg border border-border-main rounded-lg p-6">
                       <div className="mb-6 flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div>
                               <h4 className="text-[11px] font-bold uppercase text-text-main tracking-widest">Global Attack Vectors</h4>
                               <p className="text-[10px] text-text-dim font-mono uppercase">Live Origin Context</p>
                            </div>
                            <div className="h-8 w-px bg-border-main" />
                            <div className="flex gap-4">
                               <div className="flex flex-col">
                                  <span className="text-[11px] font-bold text-red-ai">NA_EAST</span>
                                  <span className="text-[8px] text-text-dim uppercase">High Vol.</span>
                               </div>
                               <div className="flex flex-col">
                                  <span className="text-[11px] font-bold text-warning">ASIA_CENTRAL</span>
                                  <span className="text-[8px] text-text-dim uppercase">Probe.</span>
                               </div>
                            </div>
                          </div>
                          <div className="flex gap-4">
                             <div className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-shadow-ai" /><span className="text-[9px] text-text-dim uppercase">Anomalies</span></div>
                             <div className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-red-ai" /><span className="text-[9px] text-text-dim uppercase">Critical</span></div>
                          </div>
                       </div>
                       
                       <div className="flex gap-6">
                          <div className="flex-1 h-[220px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <AreaChart data={threatData}>
                                <defs>
                                  <linearGradient id="colorThreat" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#9D50FF" stopOpacity={0.2}/>
                                    <stop offset="95%" stopColor="#9D50FF" stopOpacity={0}/>
                                  </linearGradient>
                                  <linearGradient id="colorRisk" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#FF3B3B" stopOpacity={0.2}/>
                                    <stop offset="95%" stopColor="#FF3B3B" stopOpacity={0}/>
                                  </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff03" vertical={false} />
                                <XAxis dataKey="time" stroke="#555" fontSize={9} tickLine={false} axisLine={false} />
                                <Tooltip contentStyle={{ backgroundColor: '#111113', border: '1px solid #262628', fontSize: '10px', color: '#E2E2E2' }} />
                                <Area type="monotone" dataKey="threats" stroke="#9D50FF" fillOpacity={1} fill="url(#colorThreat)" strokeWidth={1.5} />
                                <Area type="monotone" dataKey="risk" stroke="#FF3B3B" fillOpacity={1} fill="url(#colorRisk)" strokeWidth={1.5} />
                              </AreaChart>
                            </ResponsiveContainer>
                          </div>
                          <div className="w-1/3 space-y-3">
                             <label className="text-[8px] font-bold text-text-dim uppercase tracking-widest">Origin Heatmap (Mock)</label>
                             <div className="relative aspect-video bg-bg border border-border-main rounded overflow-hidden flex items-center justify-center">
                                <Activity className="text-red-ai opacity-20 w-12 h-12" />
                                <div className="absolute top-2 left-4 w-1.5 h-1.5 bg-red-ai rounded-full animate-ping" />
                                <div className="absolute top-8 left-12 w-1.5 h-1.5 bg-red-ai rounded-full animate-ping delay-300" />
                                <div className="absolute bottom-4 right-8 w-1.5 h-1.5 bg-warning rounded-full animate-ping delay-700" />
                                <div className="absolute inset-0 bg-shadow-ai/5" />
                                <p className="absolute bottom-2 left-2 text-[7px] font-mono text-text-dim uppercase">Real-time coordinates active</p>
                             </div>
                             <div className="space-y-1">
                                <div className="flex justify-between text-[9px]"><span className="text-text-dim">DDoS Source:</span> <span className="text-red-ai">182.42.11.x</span></div>
                                <div className="flex justify-between text-[9px]"><span className="text-text-dim">Origin:</span> <span className="text-text-main">Pyongyang, KP</span></div>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="bg-card-bg border border-border-main rounded-lg p-6">
                       <h4 className="text-[10px] font-bold uppercase text-text-main tracking-widest mb-6 border-b border-border-main pb-2">User Access Monitoring</h4>
                       <div className="space-y-4">
                          {insiderThreats.slice(0, 4).map(threat => (
                            <div key={threat.id} className="flex flex-col gap-1">
                               <div className="flex justify-between items-center text-[11px]">
                                  <span className="font-bold">{threat.name}</span>
                                  <span className={cn("font-mono text-[9px]", threat.riskScore > 70 ? "text-red-ai" : "text-text-dim")}>{threat.riskScore}% RISK</span>
                               </div>
                               <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                  <div className={cn("h-full", threat.riskScore > 70 ? "bg-red-ai" : "bg-shadow-ai")} style={{ width: `${threat.riskScore}%` }} />
                               </div>
                               <div className="flex justify-between text-[8px] text-text-dim italic">
                                  <span>{threat.department}</span>
                                  <span>{threat.location}</span>
                               </div>
                            </div>
                          ))}
                       </div>
                       <button onClick={() => setActiveTab("threats")} className="w-full mt-6 py-2 border border-white/5 rounded text-[9px] font-bold hover:bg-white/5 transition-colors">VIEW ALL ACTIVE AGENTS</button>
                    </div>
                  </div>

                  {/* Section 4 & 6: Vulnerabilities & Detailed Logs */}
                  <div className="grid grid-cols-2 gap-6">
                    <div className="bg-card-bg border border-border-main rounded-lg p-6">
                       <h4 className="text-[10px] font-bold uppercase text-text-main tracking-widest mb-4 flex items-center justify-between">
                         Vulnerability Management 
                         <span className="text-[8px] bg-red-ai/10 text-red-ai px-1.5 py-0.5 rounded">NEW CVEs FOUND</span>
                       </h4>
                       <div className="space-y-3">
                          {vulnerabilities.slice(0, 3).map(v => (
                            <div key={v.id} className="p-3 bg-bg border border-border-main rounded-md flex justify-between items-center group hover:border-shadow-ai transition-colors">
                               <div>
                                  <div className="text-[11px] font-bold text-shadow-ai">{v.id}</div>
                                  <div className="text-[10px] text-text-dim truncate max-w-[200px]">{v.description}</div>
                               </div>
                               <span className={cn(
                                 "text-[8px] font-black uppercase px-2 py-0.5 rounded",
                                 v.severity === 'critical' ? 'bg-red-ai text-white' : 'bg-warning text-black'
                               )}>{v.severity}</span>
                            </div>
                          ))}
                       </div>
                       <button onClick={() => setActiveTab("vulnerabilities")} className="w-full mt-4 text-[9px] font-bold text-text-dim hover:text-text-main uppercase tracking-widest">Open Vulnerability Console</button>
                    </div>

                    <div className="bg-card-bg border border-border-main rounded-lg p-6">
                       <h4 className="text-[10px] font-bold uppercase text-text-main tracking-widest mb-4">Event Correlation Engine</h4>
                       <div className="space-y-2 font-mono text-[10px] text-text-dim">
                          {logs.slice(0, 6).map(l => (
                            <div key={l.id} className="flex gap-3 items-center border-b border-white/5 pb-2">
                               <span className="text-text-dim shrink-0">[{new Date(l.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}]</span>
                               <span className={cn("font-bold uppercase", l.severity === 'critical' ? 'text-red-ai' : 'text-shadow-ai')}>{l.type}</span>
                               <span className="truncate">{l.message}</span>
                            </div>
                          ))}
                       </div>
                       <button onClick={() => setActiveTab("settings")} className="w-full mt-4 text-[9px] font-bold text-text-dim hover:text-text-main uppercase tracking-widest">Analyze Master Logs</button>
                    </div>
                  </div>

                  {/* Section 8: Rapid Reports */}
                  <div className="bg-card-bg border border-border-main rounded-lg p-6">
                     <div className="flex items-center justify-between mb-6">
                        <h4 className="text-[10px] font-bold uppercase text-text-main tracking-widest">Reports & Trend Analysis</h4>
                        <div className="flex gap-2">
                           <button className="px-3 py-1 bg-white/5 border border-white/10 rounded text-[9px] font-bold uppercase">Export CSV</button>
                           <button className="px-3 py-1 bg-white/5 border border-white/10 rounded text-[9px] font-bold uppercase">Export PDF</button>
                        </div>
                     </div>
                     <div className="grid grid-cols-3 gap-6">
                        <TrendCard label="Risk Reduction" value="-12.4%" positive={false} />
                        <TrendCard label="Detection Speed" value="14ms" positive />
                        <TrendCard label="Resolution Rate" value="+4.2%" positive />
                     </div>
                  </div>
                </motion.div>
              )}

              {activeTab === "vulnerabilities" && (
                <motion.div key="vul" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="bg-card-bg border border-border-main rounded-lg overflow-hidden">
                      <div className="px-6 py-4 border-b border-border-main bg-card-bg/50">
                         <h3 className="text-[12px] font-bold">Comprehensive Vulnerability Matrix</h3>
                      </div>
                      <table className="w-full text-left text-[11px] font-mono">
                         <thead className="bg-[#0d0d0f] text-text-dim uppercase text-[9px]">
                            <tr>
                               <th className="p-4 font-normal">CVE ID</th>
                               <th className="p-4 font-normal">Component</th>
                               <th className="p-4 font-normal">Threat Level</th>
                               <th className="p-4 font-normal">Patch Status</th>
                               <th className="p-4 font-normal text-right">Details</th>
                            </tr>
                         </thead>
                         <tbody className="divide-y divide-border-main/20">
                            {vulnerabilities.map(v => (
                              <tr key={v.id} className="hover:bg-white/[0.02]">
                                 <td className="p-4 text-shadow-ai font-bold">{v.id}</td>
                                 <td className="p-4 text-text-main">{v.affected}</td>
                                 <td className="p-4">
                                    <span className={cn(
                                      "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter border",
                                      v.severity === 'critical' ? 'bg-red-ai/10 text-red-ai border-red-ai/20' : 'bg-warning/10 text-warning border-warning/20'
                                    )}>{v.severity}</span>
                                 </td>
                                 <td className="p-4 text-text-dim uppercase">{v.status}</td>
                                 <td className="p-4 text-right text-text-dim italic truncate max-w-[200px]">{v.description}</td>
                              </tr>
                            ))}
                         </tbody>
                      </table>
                   </div>
                </motion.div>
              )}

              {activeTab === "health" && (
                <motion.div key="health" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   {systemHealth && (
                     <>
                        <div className="grid grid-cols-3 gap-6">
                           <div className="bg-card-bg border border-border-main p-6 rounded-lg text-center">
                              <h4 className="text-[10px] font-bold text-text-dim uppercase mb-4">Master Server Status</h4>
                              <div className="flex items-center justify-center gap-3">
                                 <div className="w-4 h-4 rounded-full bg-success animate-pulse" />
                                 <span className="text-3xl font-black uppercase text-success">{systemHealth.serverStatus}</span>
                              </div>
                           </div>
                           <div className="bg-card-bg border border-border-main p-6 rounded-lg text-center">
                              <h4 className="text-[10px] font-bold text-text-dim uppercase mb-4">Network Integrity</h4>
                              <div className="text-4xl font-black text-blue-ai">{systemHealth.networkHealth}%</div>
                           </div>
                           <div className="bg-card-bg border border-border-main p-6 rounded-lg text-center">
                              <h4 className="text-[10px] font-bold text-text-dim uppercase mb-4">Total Uptime</h4>
                              <div className="text-xl font-bold font-mono text-text-main mt-2">{systemHealth.uptime}</div>
                           </div>
                        </div>

                        <div className="bg-card-bg border border-border-main rounded-lg p-6">
                           <h4 className="text-[10px] font-bold text-text-dim uppercase mb-6 tracking-widest">Active API Integrations</h4>
                           <div className="grid grid-cols-3 gap-4">
                              {systemHealth.apiIntegrations.map((api: any) => (
                                <div key={api.name} className="flex items-center justify-between p-4 bg-bg border border-border-main rounded-md">
                                   <div className="flex items-center gap-3">
                                      <Network size={16} className="text-shadow-ai" />
                                      <span className="text-sm font-bold">{api.name}</span>
                                   </div>
                                   <span className={cn(
                                     "text-[8px] font-black uppercase px-2 py-0.5 rounded",
                                     api.status === 'connected' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
                                   )}>{api.status}</span>
                                </div>
                              ))}
                           </div>
                        </div>
                     </>
                   )}
                </motion.div>
              )}

              {activeTab === "shadow-ai" && (
                <motion.div key="sai" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                  <div className="bg-card-bg border border-border-main rounded-lg p-6">
                    <h3 className="text-lg font-bold mb-1 tracking-tight">Shadow AI Interceptor</h3>
                    <p className="text-[10px] text-text-dim uppercase tracking-widest font-bold mb-8 italic">Monitoring External LLM Gateways // Real-time Classification</p>
                    
                    <div className="grid grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <label className="text-[10px] font-bold text-text-dim uppercase">User Submission</label>
                          <textarea 
                            value={interceptInput}
                            onChange={(e) => setInterceptInput(e.target.value)}
                            placeholder="Enter prompt to intercept..."
                            className="w-full h-40 bg-bg border border-border-main rounded-md p-4 text-[13px] font-mono outline-none focus:border-shadow-ai transition-colors resize-none"
                          />
                          <button 
                            onClick={handleIntercept}
                            disabled={isIntercepting}
                            className="w-full py-3 bg-shadow-ai hover:opacity-90 transition-opacity rounded-md text-xs font-bold tracking-widest flex items-center justify-center gap-2"
                          >
                            {isIntercepting ? <RefreshCw size={14} className="animate-spin" /> : <Shield size={14} />}
                            {isIntercepting ? "CLASSIFYING..." : "ANALYZE SECURITY PAYLOAD"}
                          </button>
                       </div>

                       <div className="space-y-4">
                          <label className="text-[10px] font-bold text-text-dim uppercase">Blue AI Intelligence</label>
                          <div className="h-[212px] bg-[#0d0d0f] border border-border-main rounded-md p-5 font-mono text-[11px] overflow-auto">
                             {interceptResult ? (
                               <div className="space-y-4">
                                  <div className="flex justify-between items-center">
                                    <span className="text-text-dim">POLICY DECISION:</span>
                                    <span className={cn(
                                      "px-2 py-0.5 rounded text-[9px] font-bold border",
                                      interceptResult.action === "ALLOW" ? "bg-success/5 text-success border-success/20" :
                                      interceptResult.action === "BLOCK" ? "bg-red-ai/5 text-red-ai border-red-ai/20" : "bg-warning/5 text-warning border-warning/20"
                                    )}>
                                      {interceptResult.action}
                                    </span>
                                  </div>
                                  <div className="flex justify-between items-center text-text-dim">
                                    <span>RISK CONFIDENCE:</span>
                                    <span className="text-text-main">{interceptResult.riskScore}%</span>
                                  </div>
                                  <div className="flex flex-wrap gap-2 pt-2">
                                     {interceptResult.classification.map((c: string) => (
                                       <span key={c} className="bg-white/5 border border-border-main px-2 py-0.5 rounded-[3px] text-[8px] uppercase tracking-wider">{c}</span>
                                     ))}
                                  </div>
                                  <p className="text-text-dim italic mt-2 leading-relaxed">Reasoning: {interceptResult.reasoning}</p>
                               </div>
                             ) : (
                               <div className="h-full flex items-center justify-center text-text-dim/30 italic uppercase tracking-[0.2em] text-[9px]">
                                 Awaiting Intercept Signal
                               </div>
                             )}
                          </div>
                       </div>
                    </div>

                    {interceptResult?.maskedContent && (
                      <div className="mt-8 pt-6 border-t border-border-main">
                        <div className="flex items-center gap-2 mb-3">
                          <EyeOff size={12} className="text-success" />
                          <span className="text-[10px] font-bold uppercase text-success tracking-widest">Dynamic Masking Result</span>
                        </div>
                        <div className="p-4 bg-success/5 border border-success/10 rounded-md font-mono text-[11px] text-success/90 italic">
                          {interceptResult.maskedContent}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {activeTab === "simulation" && (
                <motion.div key="sim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                  <div className="glass-panel rounded-2xl overflow-hidden flex flex-col h-full min-h-[500px]">
                    <div className="px-8 py-6 border-b border-border-main flex items-center justify-between bg-white/[0.02]">
                      <div>
                        <h3 className="text-sm font-bold tracking-tight uppercase">AI Adversarial Proving Ground</h3>
                        <p className="text-[9px] text-text-dim uppercase font-mono mt-1 tracking-widest">Neural Training Pipeline // V12.4</p>
                      </div>
                      <button 
                        onClick={handleSimulate}
                        disabled={isSimulating}
                        className="bg-red-ai/10 hover:bg-red-ai/20 border border-red-ai/30 text-red-ai px-6 py-2 rounded-lg text-[10px] font-bold tracking-widest transition-all flex items-center gap-3 backdrop-blur-md"
                      >
                         {isSimulating ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
                         ENGAGE RED TEAM
                      </button>
                    </div>

                    <div className="grid grid-cols-4 border-b border-border-main bg-black/40 text-[9px] uppercase font-bold tracking-[0.2em] p-5 text-center">
                       <div className="border-r border-border-main"><span className="text-text-dim block mb-1">Attack Success</span><span className="text-red-ai">4.2%</span></div>
                       <div className="border-r border-border-main"><span className="text-text-dim block mb-1">Detection Win Rate</span><span className="text-success">95.8%</span></div>
                       <div className="border-r border-border-main"><span className="text-text-dim block mb-1">MTTD (Neural)</span><span className="text-blue-ai">12ms</span></div>
                       <div><span className="text-text-dim block mb-1">Node Resilience</span><span className="text-warning">88%</span></div>
                    </div>

                    <div className="flex-1 grid grid-cols-2">
                       {/* Red AI Feed */}
                       <div className="border-r border-border-main p-8 font-mono text-[11px] space-y-5 bg-red-ai/[0.01]">
                          <div className="flex items-center gap-3 mb-6">
                             <span className="w-1.5 h-1.5 rounded-full bg-red-ai shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                             <span className="text-red-ai font-bold uppercase text-[10px] tracking-widest">Red AI Stream</span>
                          </div>
                          {simulation ? (
                            <div className="space-y-5 text-text-dim">
                               <p className="text-text-main font-bold border-l-2 border-red-ai/40 pl-3">[ATTACK_SIGNATURE]: {simulation.attackType}</p>
                               <div className="space-y-3 pl-3">
                                  {simulation.steps.map((s: string, i: number) => (
                                    <p key={i} className="flex gap-4">
                                       <span className="text-red-ai/40 font-bold w-4">0{i+1}</span>
                                       <span className="opacity-80 font-medium tracking-tight"> {s}</span>
                                    </p>
                                  ))}
                               </div>
                               <div className="mt-6 p-4 bg-black/60 rounded-xl border border-red-ai/10 text-[10px] text-red-ai/80 font-medium">
                                  <span className="block opacity-40 mb-1 uppercase text-[8px]">Compiled Payload</span>
                                  {simulation.payload}
                                </div>
                            </div>
                          ) : (
                            <div className="py-20 flex flex-col items-center justify-center opacity-20 gap-4">
                               <Terminal size={32} />
                               <p className="text-[10px] font-bold uppercase tracking-widest italic">Awaiting Adversarial Trigger</p>
                            </div>
                          )}
                       </div>

                       {/* Shadow AI Feed */}
                       <div className="p-6 font-mono text-[11px] space-y-4 bg-shadow-ai/[0.02]">
                          <div className="flex items-center gap-2 mb-4">
                             <span className="w-2 h-2 rounded-full bg-shadow-ai" />
                             <span className="text-shadow-ai font-bold uppercase text-[10px]">Shadow AI Defensive Link</span>
                          </div>
                          {playbook ? (
                            <div className="text-shadow-ai/90 whitespace-pre-wrap leading-relaxed">
                               {playbook}
                            </div>
                          ) : (
                            <p className="text-text-dim/20 italic py-10">Listening for attack signature...</p>
                          )}
                       </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === "threats" && (
                <motion.div key="ti" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="bg-card-bg border border-border-main rounded-lg overflow-hidden">
                      <div className="px-6 py-4 border-b border-border-main bg-card-bg/50">
                         <h3 className="text-[12px] font-bold">Comprehensive Threat Intelligence</h3>
                      </div>
                      <table className="w-full text-left text-[11px] font-mono">
                        <thead className="bg-[#0d0d0f] text-text-dim uppercase text-[9px]">
                          <tr>
                            <th className="p-4 font-normal">Timestamp</th>
                            <th className="p-4 font-normal">Event Source</th>
                            <th className="p-4 font-normal">Detected Pattern</th>
                            <th className="p-4 font-normal">Risk Level</th>
                            <th className="p-4 font-normal text-right">Integrity</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border-main/20">
                           {insiderThreats.map((threat) => (
                             <ThreatRow 
                               key={threat.id}
                               time={new Date().toLocaleTimeString()} 
                               source={threat.name} 
                               pattern={threat.lastAction} 
                               risk={threat.riskScore > 80 ? "Critical" : threat.riskScore > 40 ? "Medium" : "Low"} 
                               action={threat.riskScore > 50 ? "BLOCK & ALERT" : "ALLOWED"} 
                               onAnalyze={() => handleIntelligenceAnalysis(threat)}
                               isAnalyzing={analyzingThreatId === threat.id}
                             />
                           ))}
                        </tbody>
                      </table>
                   </div>
                </motion.div>
              )}

              {activeTab === "blue-ai" && (
                <motion.div key="bai" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="grid grid-cols-2 gap-6">
                      <div className="bg-card-bg border border-border-main rounded-lg p-6">
                        <h4 className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-4">Classification Accuracy</h4>
                        <div className="text-4xl font-black text-blue-ai">99.8%</div>
                        <p className="text-[10px] text-text-dim mt-2 italic font-mono uppercase">Neural weights optimized for DPDPA patterns</p>
                      </div>
                      <div className="bg-card-bg border border-border-main rounded-lg p-6">
                        <h4 className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-4">Total Decisions</h4>
                        <div className="text-4xl font-black text-text-main">1,248,312</div>
                        <p className="text-[10px] text-text-dim mt-2 italic font-mono uppercase">Last 24 hours total volume</p>
                      </div>
                   </div>
                   <div className="bg-card-bg border border-border-main rounded-lg p-6">
                      <h4 className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-4">Recent Decision Stream</h4>
                      <div className="space-y-3 font-mono text-[11px]">
                         {logs.filter(l => l.type === 'SHADOW_AI').map(l => (
                           <div key={l.id} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0 opacity-70">
                              <span>[{new Date(l.timestamp).toLocaleTimeString()}] {l.message}</span>
                              <span className="text-blue-ai font-bold">VERIFIED</span>
                           </div>
                         ))}
                      </div>
                   </div>
                </motion.div>
              )}

              {activeTab === "shadow-brain" && (
                <motion.div key="sb" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="glass-panel p-8 rounded-2xl">
                      <div className="flex items-center gap-6 mb-10">
                        <div className="w-16 h-16 bg-shadow-ai/10 rounded-2xl flex items-center justify-center border border-shadow-ai/20 shadow-lg shadow-shadow-ai/5">
                          <Zap className="text-shadow-ai" size={32} />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold tracking-tight uppercase">Shadow AI Brain Library</h3>
                          <p className="text-[10px] text-text-dim uppercase font-mono mt-1 tracking-[0.2em] italic">Learned Neural Patterns // Autonomous Synchronization</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-4">
                        {playbooks.length === 0 && (
                          <div className="p-20 border border-white/5 border-dashed rounded-lg text-center text-text-dim italic opacity-30 uppercase tracking-widest text-xs">
                            No playbooks generated. Execute Red AI to begin training.
                          </div>
                        )}
                        {playbooks.map(pb => (
                          <div key={pb.id} className="bg-bg border border-border-main rounded-lg p-5 group hover:border-shadow-ai transition-colors">
                            <div className="flex justify-between items-center mb-4">
                              <h4 className="text-sm font-bold text-shadow-ai">{pb.attackType} Defense Pattern</h4>
                              <span className="text-[10px] text-text-dim font-mono">{new Date(pb.timestamp).toLocaleString()}</span>
                            </div>
                            <div className="text-[11px] text-text-dim font-mono line-clamp-3 overflow-hidden">
                               {pb.content}
                            </div>
                            <button className="mt-4 text-[10px] font-bold text-shadow-ai flex items-center gap-1 hover:underline">
                               VIEW FULL SPECIFICATION <ChevronRight size={12} />
                            </button>
                          </div>
                        ))}

                        {intelligenceReports.length > 0 && (
                           <div className="mt-10 border-t border-white/5 pt-10">
                              <h3 className="text-sm font-black tracking-widest uppercase text-text-main mb-6 flex items-center gap-2">
                                 <Brain size={14} className="text-shadow-ai" /> 
                                 Live L5 Intelligence Stream
                              </h3>
                              <div className="grid grid-cols-1 gap-4">
                                 {intelligenceReports.map((report, idx) => (
                                   <div key={idx} className="bg-shadow-ai/5 border border-shadow-ai/20 rounded-lg p-6 font-mono">
                                      <div className="flex justify-between items-center mb-4 border-b border-shadow-ai/10 pb-2">
                                         <span className="text-[12px] font-black text-shadow-ai uppercase">Correlation Report_{idx + 1}</span>
                                         <span className="text-[9px] text-text-dim italic">{new Date(report.timestamp).toLocaleTimeString()}</span>
                                      </div>
                                      <div className="grid grid-cols-2 gap-6 text-[11px]">
                                         <div className="space-y-4">
                                            <div>
                                               <span className="text-text-dim block mb-1 uppercase text-[9px]">Attack Type</span>
                                               <span className="text-text-main font-bold border-l border-shadow-ai pl-2">{report.analysis.attack_type}</span>
                                            </div>
                                            <div>
                                               <span className="text-text-dim block mb-1 uppercase text-[9px]">Neural Confidence</span>
                                               <span className="text-success font-bold border-l border-success pl-2">{(report.analysis.confidence * 100).toFixed(1)}%</span>
                                            </div>
                                         </div>
                                         <div className="space-y-4 text-right">
                                            <div className="mb-4">
                                               <span className="text-text-dim block mb-1 uppercase text-[9px]">Neural Explanation</span>
                                               <p className="text-[10px] text-text-main leading-relaxed opacity-80">{report.analysis.explanation}</p>
                                            </div>
                                            <div className="p-3 bg-shadow-ai/10 rounded border border-shadow-ai/20 inline-block text-left">
                                               <span className="text-shadow-ai block mb-1 uppercase text-[9px] font-black">AI Suggestion</span>
                                               <p className="text-[10px] text-shadow-ai italic">{report.analysis.suggestion}</p>
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                 ))}
                              </div>
                           </div>
                         )}
                      </div>
                   </div>
                </motion.div>
              )}

              {activeTab === "compliance" && (
                <motion.div key="ca" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="bg-card-bg border border-border-main rounded-lg p-8">
                      <div className="flex items-center justify-between mb-8">
                         <h3 className="text-2xl font-black tracking-tight">DPDPA COMPLIANCE AUDIT</h3>
                         <div className="flex items-center gap-2 bg-success/10 text-success border border-success/30 px-3 py-1 rounded text-[10px] font-bold">
                           <Shield size={14} /> STATUS: COMPLIANT
                         </div>
                      </div>
                      <div className="space-y-6">
                         <ComplianceItem label="User Data Anonymization" status="Active" level={100} />
                         <ComplianceItem label="Cross-Border Flow Control" status="Active" level={100} />
                         <ComplianceItem label="Right to Access Protocol" status="Ready" level={100} />
                         <ComplianceItem label="Data Breach Notification" status="Ready" level={100} />
                      </div>
                   </div>
                   <div className="bg-card-bg border border-border-main rounded-lg p-6">
                      <h4 className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-4">Audited PII Masking Events</h4>
                      <div className="space-y-2 font-mono text-[10px] text-text-dim opacity-60">
                         {logs.filter(l => l.message.includes('Masking')).map(l => (
                           <div key={l.id} className="p-2 bg-white/5 rounded">
                              {new Date(l.timestamp).toLocaleString()} // {l.message} // DPDPA_SECURED
                           </div>
                         ))}
                      </div>
                   </div>
                </motion.div>
              )}

              {activeTab === "reports" && (
                <motion.div key="rep" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="bg-card-bg border border-border-main rounded-lg p-8 max-w-4xl">
                      <div className="flex items-center justify-between mb-8">
                         <div>
                            <h3 className="text-xl font-bold tracking-tight">Intelligence & Export Center</h3>
                            <p className="text-xs text-text-dim uppercase font-mono mt-1">Generate High-Integrity Security Artifacts</p>
                         </div>
                         <div className="flex gap-3">
                            <span className="flex items-center gap-1.5 text-[10px] text-success font-bold uppercase ring-1 ring-success/30 px-2 py-1 rounded bg-success/10">
                               <Shield size={12} /> Data_Verified
                            </span>
                         </div>
                      </div>

                      <div className="grid grid-cols-2 gap-6">
                         <ReportOption 
                            title="Executive Security Summary" 
                            desc="High-level overview of risk posture, total threats prevented, and compliance status for management."
                            onExport={() => handleGeneratePDF("Executive")}
                         />
                         <ReportOption 
                            title="Technical Incident Audit" 
                            desc="Detailed log of all SHADOW_AI interceptions and Red Team simulation results for engineering audit."
                            onExport={() => handleGeneratePDF("Technical")}
                         />
                         <ReportOption 
                            title="Insider Threat Profile" 
                            desc="Comprehensive risk scores and behavioral logs for all identified high-risk agent nodes."
                            onExport={() => handleGeneratePDF("Threat")}
                         />
                         <ReportOption 
                            title="Compliance Verification (DPDPA)" 
                            desc="Official audit record for data masking efficacy and privacy vault integrity checks."
                            onExport={() => handleGeneratePDF("Compliance")}
                         />
                      </div>

                      <div className="mt-12 pt-8 border-t border-white/5 space-y-4">
                         <h4 className="text-[10px] font-bold text-text-dim uppercase tracking-widest">Global Policy Settings</h4>
                         <div className="flex items-center justify-between p-4 bg-bg border border-border-main rounded-lg">
                            <div className="flex items-center gap-4">
                               <div className="w-10 h-10 bg-shadow-ai/10 rounded flex items-center justify-center text-shadow-ai">
                                  <Activity size={20} />
                               </div>
                               <div>
                                  <div className="text-[13px] font-bold">Auto-Generate Weekly Brief</div>
                                  <div className="text-[10px] text-text-dim uppercase">Next report: Monday 00:00 UTC</div>
                               </div>
                            </div>
                            <div className="w-10 h-5 bg-shadow-ai rounded-full relative cursor-pointer">
                               <div className="absolute right-1 top-1 w-3 h-3 bg-white rounded-full shadow-md" />
                            </div>
                         </div>
                      </div>
                   </div>
                </motion.div>
              )}

              {activeTab === "settings" && (
                <motion.div key="ss" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                   <div className="bg-card-bg border border-border-main rounded-lg p-8 max-w-2xl">
                      <h3 className="text-xl font-bold mb-6">SOC Configuration</h3>
                      <div className="space-y-8">
                         <div className="flex items-center justify-between">
                            <div>
                               <h4 className="text-sm font-bold">Interceptor Autonomy Level</h4>
                               <p className="text-xs text-text-dim">Allow Shadow AI to make blocking decisions without human review.</p>
                            </div>
                            <div className="w-12 h-6 bg-shadow-ai rounded-full relative">
                               <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                            </div>
                         </div>
                         <div className="flex items-center justify-between">
                            <div>
                               <h4 className="text-sm font-bold">Cloud Training Sink</h4>
                               <p className="text-xs text-text-dim">Feed anonymized metadata back to the master neural model.</p>
                            </div>
                            <div className="w-12 h-6 bg-border-main rounded-full relative opacity-50">
                               <div className="absolute left-1 top-1 w-4 h-4 bg-white/20 rounded-full" />
                            </div>
                         </div>
                         <div className="pt-6 border-t border-white/5">
                            <button className="px-6 py-2 bg-white text-black font-black text-xs rounded hover:bg-white/90 transition-colors">
                               SAVE CONFIGURATION
                            </button>
                         </div>
                      </div>
                   </div>
                </motion.div>
              )}
               {activeTab === "architecture" && (
                 <motion.div key="arch" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 pb-20 overflow-y-auto max-h-full scrollbar-hide px-2">
                    <div className="grid grid-cols-1 gap-4 max-w-5xl">
                       <div className="mb-6">
                          <h3 className="text-2xl font-black tracking-tight uppercase">Defend X Core Architecture</h3>
                          <p className="text-[10px] text-text-dim font-mono uppercase mt-1 flex items-center gap-2">
                             <Circle className="fill-success text-success" size={8} /> 
                             Multi-Layer Integrated Defense Ecosystem // Status: Synchronized
                          </p>
                       </div>
                       {[
                         { id: 1, name: "Data & Attack Layer (Red AI)", tools: "Caldera, Metasploit", role: "Simulates adversarial behaviors and generates raw attack telemetry for neural training and stress testing.", color: "text-red-ai", icon: <Target size={16} /> },
                         { id: 2, name: "Data Collection Layer", tools: "Wazuh Agents, Vector, Logstash", role: "Passive harvesting of system, network, and application logs from distributed endpoint nodes.", color: "text-blue-ai", icon: <Database size={16} /> },
                         { id: 3, name: "Detection Layer (Blue AI)", tools: "Zeek, Wazuh Manager, Elastic Security", role: "Live packet analysis and signature-based anomaly detection triggered by raw collectors in real-time.", color: "text-blue-ai", icon: <Eye size={16} /> },
                         { id: 4, name: "Processing & Normalization Layer", tools: "FastAPI, Structured Logging, Regex", role: "Translating disparate tool outputs into a unified JSON security schema for the neural analytical engine.", color: "text-text-main", icon: <Filter size={16} /> },
                         { id: 5, name: "Intelligence Layer (Core AI/Shadow AI)", tools: "Ollama (DeepSeek), Gemini 3.5", role: "Deep reasoning, risk scoring, and explainable threat analysis. The 'Neural Brain' of the platform.", color: "text-shadow-ai", icon: <Cpu size={16} /> },
                         { id: 6, name: "Decision & Response Layer", tools: "Auto-Containment, MFA-Forced-Key", role: "Automated mitigation steps based on intelligence confidence thresholds and pre-defined SOAR rules.", color: "text-warning", icon: <Zap size={16} /> },
                         { id: 7, name: "Storage & Learning Layer", tools: "FAISS Vector DB, PostgreSQL", role: "Long-term episodic memory storing attack patterns to improve future neural inference accuracy.", color: "text-text-dim", icon: <History size={16} /> },
                         { id: 8, name: "API & Control Layer", tools: "FastAPI Gateway, WebSockets", role: "The command-and-control bridge connecting all SOC components to the Defend X command interface.", color: "text-text-main", icon: <Network size={16} /> }
                       ].map((layer) => (
                         <div key={layer.id} className="bg-card-bg border border-border-main p-6 rounded-lg flex gap-6 items-start hover:border-white/20 transition-all hover:translate-x-1">
                            <div className="w-12 h-12 rounded bg-white/5 flex flex-col items-center justify-center shrink-0 border border-white/5 shadow-inner">
                               <span className="text-[10px] font-black text-text-dim italic">L{layer.id}</span>
                               <div className={cn("mt-1", layer.color)}>{layer.icon}</div>
                            </div>
                            <div className="flex-1">
                               <div className="flex items-center gap-3 mb-1.5">
                                  <h4 className="font-bold text-sm tracking-tight">{layer.name}</h4>
                                  <span className="text-[10px] font-mono px-2 py-0.5 bg-white/5 rounded text-text-dim border border-white/5 uppercase tracking-tighter">{layer.tools}</span>
                               </div>
                               <p className="text-[11px] text-text-dim leading-relaxed max-w-2xl">{layer.role}</p>
                            </div>
                         </div>
                       ))}
                    </div>
                 </motion.div>
               )}
            </AnimatePresence>
          </div>

          {/* Bottom Simulation Stream Panel */}
          <div className="h-[200px] bg-card-bg border-t border-border-main p-6 overflow-hidden flex flex-col shrink-0">
             <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] font-bold uppercase tracking-widest text-shadow-ai">AI Event Stream</span>
                <span className="text-[9px] text-text-dim">Log Level: Trace</span>
             </div>
             <div className="flex-1 overflow-auto font-mono text-[10px] space-y-2 scrollbar-hide">
                {logs.slice(-30).map((log) => (
                  <div key={log.id} className="flex gap-4 opacity-60 hover:opacity-100 transition-opacity">
                    <span className="text-text-dim shrink-0">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                    <span className={cn(
                      "shrink-0 font-bold",
                      log.severity === "critical" ? "text-red-ai" :
                      log.severity === "high" ? "text-red-ai/80" :
                      log.severity === "medium" ? "text-warning" : "text-success"
                    )}>{log.type.toUpperCase()}{log.layer ? `_L${log.layer}` : ""}</span>
                    <span className="text-text-dim/80 font-bold uppercase shrink-0">[{log.source || "SYSTEM"}]</span>
                    <span className="text-text-main">// {log.message}</span>
                  </div>
                ))}
             </div>
          </div>
        </section>

        {/* Right Sidebar Intelligence */}
        <aside className="w-[300px] p-8 flex flex-col gap-8 shrink-0 bg-bg overflow-y-auto overflow-x-hidden border-l border-border-main">
          <Section label="Neural Intelligence" />
          
          <IntelligenceCard title="Agent Risk Delta">
             <div className="text-4xl font-extralight py-3 font-sans tracking-tighter">
               {(insiderThreats.length > 0 
                 ? (insiderThreats.reduce((acc, t) => acc + t.riskScore, 0) / (insiderThreats.length * 10)).toFixed(1)
                 : "0.0")} 
               <span className="text-sm font-normal text-text-dim opacity-40"> / 10</span>
             </div>
             <p className="text-[10px] text-text-dim mb-6 tracking-tight font-medium uppercase">Trending <span className="text-red-ai font-bold">+1.2%</span> // Cycle 08</p>
             <div className="flex flex-wrap gap-2">
                <Tag label="PII Breach" />
                <Tag label="Neural Bypass" />
                <Tag label="Protocol_Error" />
             </div>
          </IntelligenceCard>

          <IntelligenceCard title="Active AI Engines">
             <div className="space-y-4 mt-2">
                <EngineItem name="Red (Attacker)" active />
                <EngineItem name="Blue (Defender)" active />
                <EngineItem name="Shadow (Learn)" active />
             </div>
          </IntelligenceCard>

          <IntelligenceCard title="Compliance Health" gradient>
             <div className="text-lg font-bold text-success mt-1 uppercase tracking-widest">Secure</div>
             <p className="text-[10px] text-text-dim mt-2 leading-relaxed">
                DPDPA decision validation layer operational. Zero unauthorized PII exposures detected in last 24h cycle.
             </p>
          </IntelligenceCard>

          <div className="mt-auto pt-6 flex flex-col gap-3">
             <InfrastructureItem label="DPDPA Privacy Vault" status="Sealed" load={metrics.nodeLoads[3]} />
             <InfrastructureItem label="Gateway Broker" status="Syncing" load={metrics.nodeLoads[0]} />
             <InfrastructureItem label="Blue AI Parser (H100)" status="Processing" load={metrics.nodeLoads[2]} />
             <InfrastructureItem label="Red AI Neural Engine" status="Calculating" load={metrics.nodeLoads[1]} />
          </div>
        </aside>
      </main>
    </div>
  );
}

function NavGroup({ title, children }: { title: string, children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <h3 className="text-[10px] font-bold text-text-dim uppercase tracking-[0.2em] mb-4">{title}</h3>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function NavItem({ active, onClick, label, icon }: { active?: boolean, onClick?: () => void, label: string, icon: React.ReactNode }) {
  return (
    <div 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer text-[13px] transition-all group",
        active 
          ? "bg-white/5 text-text-main border-l-2 border-shadow-ai pl-2.5 rounded-l-none" 
          : "text-text-dim hover:text-text-main hover:bg-white/[0.02]"
      )}
    >
      <span className={cn("transition-colors", active ? "text-shadow-ai" : "text-text-dim group-hover:text-text-main")}>{icon}</span>
      <span className="font-medium tracking-tight">{label}</span>
      {active && <ChevronRight size={12} className="ml-auto opacity-40" />}
    </div>
  );
}

function Section({ label }: { label: string }) {
  return (
    <div className="text-[10px] font-bold text-text-dim uppercase tracking-widest border-b border-border-main pb-2 mb-2">{label}</div>
  );
}

function IntelligenceCard({ title, children, gradient }: { title: string, children: React.ReactNode, gradient?: boolean }) {
  return (
    <div className={cn(
      "p-5 rounded-lg border border-border-main bg-card-bg",
      gradient && "bg-gradient-to-b from-[#151518] to-card-bg"
    )}>
      <h4 className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-3">{title}</h4>
      {children}
    </div>
  );
}

function Tag({ label }: { label: string }) {
  return (
    <span className="text-[9px] bg-white/5 border border-border-main px-2 py-0.5 rounded text-text-dim uppercase font-bold tracking-tighter cursor-default hover:text-text-main transition-colors">{label}</span>
  );
}

function TrendCard({ label, value, positive }: { label: string, value: string, positive: boolean }) {
  return (
    <div className="bg-bg border border-border-main/50 p-4 rounded flex flex-col items-center">
       <span className="text-[9px] font-bold text-text-dim uppercase tracking-widest mb-1">{label}</span>
       <span className={cn("text-xl font-black", positive ? "text-success" : "text-red-ai")}>{value}</span>
       <div className={cn("text-[8px] uppercase mt-1 font-bold", positive ? "text-success/50" : "text-red-ai/50")}>
          {positive ? "Positive Growth" : "Optimization Required"}
       </div>
    </div>
  );
}

function EngineItem({ name, active }: { name: string, active: boolean }) {
  return (
    <div className="flex items-center justify-between text-xs font-medium">
       <span className="text-text-dim">{name}</span>
       <span className={cn("flex items-center gap-2", active ? "text-success" : "text-text-dim")}>
          <span className={cn("w-1.5 h-1.5 rounded-full", active ? "bg-success shadow-[0_0_8px_rgba(0,255,163,0.5)]" : "bg-text-dim")} />
          {active ? "ACTIVE" : "OFFLINE"}
       </span>
    </div>
  );
}

function HeaderStat({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="flex flex-col items-end">
       <span className="text-[9px] font-bold uppercase tracking-tight text-text-dim">{label}</span>
       <span className={cn("text-xs font-mono font-bold", color)}>{value}</span>
    </div>
  );
}

function DashboardStat({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="glass-panel p-5 rounded-xl hover:border-white/10 transition-all">
      <div className="text-[9px] font-bold uppercase text-text-dim mb-2 tracking-[0.2em]">{label}</div>
      <div className={cn("text-3xl font-light font-sans tracking-tighter", color)}>{value}</div>
    </div>
  );
}

function ReportOption({ title, desc, onExport }: { title: string, desc: string, onExport: () => void }) {
  return (
    <div className="p-6 glass-panel rounded-xl group hover:border-shadow-ai/30 transition-all">
       <div className="flex flex-col h-full">
          <h4 className="text-[13px] font-bold mb-3 flex items-center gap-3 transition-colors uppercase tracking-tight">
             <div className="w-1.5 h-1.5 rounded-full bg-shadow-ai group-hover:animate-pulse" /> {title}
          </h4>
          <p className="text-[11px] text-text-dim leading-relaxed mb-6 flex-1 font-medium">
             {desc}
          </p>
          <button 
            onClick={onExport}
            className="w-full py-3 bg-white/5 border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-shadow-ai hover:text-white transition-all flex items-center justify-center gap-2 shadow-inner"
          >
             <Activity size={12} /> Sync & Download
          </button>
       </div>
    </div>
  );
}

function ActionBox({ title, desc, btnLabel, onClick, color }: { title: string, desc: string, btnLabel: string, onClick: () => void, color: 'red' | 'shadow' }) {
  const colorStyles = {
    red: "bg-red-ai border-red-ai/20 shadow-red-ai/10",
    shadow: "bg-shadow-ai border-shadow-ai/20 shadow-shadow-ai/10"
  };
  return (
    <div className="bg-card-bg border border-border-main p-6 rounded-lg group hover:border-white/10 transition-colors">
       <h4 className="font-bold text-sm mb-2">{title}</h4>
       <p className="text-[11px] text-text-dim mb-6 leading-relaxed">{desc}</p>
       <button 
         onClick={onClick}
         className={cn(
           "w-full py-2 rounded text-[10px] font-black tracking-[0.2em] transition-all shadow-lg hover:brightness-110",
           colorStyles[color]
         )}
       >
         {btnLabel}
       </button>
    </div>
  );
}

interface ThreatRowProps {
  time: string;
  source: string;
  pattern: string;
  risk: string;
  action: string;
  onAnalyze?: () => void;
  isAnalyzing?: boolean;
}

const ThreatRow: React.FC<ThreatRowProps> = ({ time, source, pattern, risk, action, onAnalyze, isAnalyzing }) => {
  return (
    <tr className="hover:bg-white/[0.02] transition-colors border-b border-border-main/10 last:border-0 group">
       <td className="p-4 text-text-dim">{time}</td>
       <td className="p-4 text-text-main font-bold">{source}</td>
       <td className="p-4 text-text-dim italic">"{pattern}"</td>
       <td className="p-4">
          <span className={cn(
            "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter border",
            risk === "Critical" ? "bg-red-ai/10 text-red-ai border-red-ai/20" : "bg-warning/10 text-warning border-warning/20"
          )}>
            {risk}
          </span>
       </td>
       <td className="p-4 text-right">
          <div className="flex items-center justify-end gap-3">
            <span className={cn(
              "text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded",
               action.includes("BLOCK") ? "text-red-ai bg-red-ai/10" : "text-warning bg-warning/10"
            )}>{action}</span>
            <button 
               onClick={onAnalyze}
               disabled={isAnalyzing}
               className="bg-shadow-ai/10 text-shadow-ai border border-shadow-ai/20 px-3 py-1 rounded text-[9px] font-bold hover:bg-shadow-ai hover:text-white transition-all scale-0 group-hover:scale-100 flex items-center gap-1"
            >
               {isAnalyzing ? <RefreshCw size={10} className="animate-spin" /> : <Brain size={10} />}
               L5 ANALYSIS
            </button>
          </div>
       </td>
    </tr>
  );
}

function InfrastructureItem({ label, status, load }: { label: string, status: string, load: number }) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-[9px] font-bold uppercase tracking-tight">
        <span className="text-text-dim">{label}</span>
        <span className={cn(
          "tracking-[0.1em]",
          status === "Healthy" || status === "Sealed" ? "text-success" : "text-warning animate-pulse"
        )}>{status}</span>
      </div>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden p-[0.5px]">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${load === 0 ? 100 : load}%` }}
          className={cn(
            "h-full rounded-full transition-all duration-1000",
            load > 85 ? "bg-red-ai" : 
            load > 35 ? "bg-warning" : "bg-shadow-ai"
          )}
        />
      </div>
    </div>
  );
}

function ComplianceItem({ label, status, level }: { label: string, status: string, level: number }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-bold">{label}</span>
        <span className="text-[10px] font-mono text-success uppercase">{status}</span>
      </div>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }} 
          animate={{ width: `${level}%` }} 
          className="h-full bg-success shadow-[0_0_8px_rgba(0,255,163,0.3)]" 
        />
      </div>
    </div>
  );
}
