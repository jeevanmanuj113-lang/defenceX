import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, Lock, Mail, User, ArrowRight, ShieldCheck, Terminal, AlertCircle, RefreshCw } from "lucide-react";
import { cn } from "../lib/utils";

interface AuthPageProps {
  onLogin: (user: any) => void;
}

export function AuthPage({ onLogin }: AuthPageProps) {
  const [isNewUser, setIsNewUser] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 1500));

    if (isNewUser && !name) {
      setError("Identification name required for neural mapping.");
      setIsLoading(false);
      return;
    }

    if (!email.includes("@") || password.length < 6) {
      setError("Invalid credentials. Standard security protocols not met.");
      setIsLoading(false);
      return;
    }

    // Success simulation
    const userData = { email, name: name || email.split("@")[0], id: "usr_" + Math.random().toString(36).substr(2, 9) };
    localStorage.setItem("defend_x_user", JSON.stringify(userData));
    onLogin(userData);
  };

  return (
    <div className="min-h-screen w-full bg-[#070708] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Background Grid & Effects */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-shadow-ai/5 via-transparent to-transparent pointer-events-none" />
      
      {/* Decorative Binary Rain Suggestion or Animated Glows */}
      <motion.div 
        animate={{ 
          opacity: [0.1, 0.3, 0.1],
          scale: [1, 1.1, 1] 
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        className="absolute -top-24 -left-24 w-96 h-96 bg-shadow-ai/10 rounded-full blur-[120px]" 
      />
      <motion.div 
        animate={{ 
          opacity: [0.1, 0.2, 0.1],
          scale: [1, 1.2, 1] 
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear", delay: 2 }}
        className="absolute -bottom-24 -right-24 w-96 h-96 bg-blue-ai/10 rounded-full blur-[120px]" 
      />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-[420px]"
      >
        <div className="bg-card-bg/50 backdrop-blur-xl border border-border-main rounded-2xl p-8 shadow-2xl shadow-black/50">
          {/* Logo Section */}
          <div className="flex flex-col items-center mb-12">
            <motion.div 
              whileHover={{ rotate: 180, scale: 1.05 }}
              transition={{ duration: 0.8, ease: "circOut" }}
              className="w-20 h-20 bg-shadow-ai rounded-3xl flex items-center justify-center shadow-2xl shadow-shadow-ai/30 mb-8 relative group"
            >
              <div className="absolute inset-0 bg-white/20 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity blur-xl" />
              <Shield className="text-white w-10 h-10 relative z-10" />
            </motion.div>
            <h1 className="text-3xl font-black tracking-tighter uppercase text-text-main flex items-baseline">
              DEFEND<span className="text-shadow-ai text-5xl italic font-serif">.</span>X
            </h1>
            <p className="text-[10px] text-text-dim font-black tracking-[0.5em] uppercase mt-4 opacity-50">
              Neural Defense Architecture // V4.0
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <AnimatePresence mode="wait">
              {isNewUser && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="space-y-2"
                >
                  <label className="text-[10px] font-black text-text-dim uppercase tracking-[0.2em] flex items-center gap-3 ml-1">
                    <User size={12} className="text-shadow-ai/60" /> Agent Identity
                  </label>
                  <input 
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="FULL_NAME_REQUEST"
                    className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-4 text-[13px] font-mono outline-none focus:border-shadow-ai/50 transition-all text-text-main placeholder:text-text-dim/30 shadow-inner"
                  />
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-text-dim uppercase tracking-[0.2em] flex items-center gap-3 ml-1">
                <Mail size={12} className="text-shadow-ai/60" /> Neural Link
              </label>
              <input 
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="AGENT_ID_00"
                className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-4 text-[13px] font-mono outline-none focus:border-shadow-ai/50 transition-all text-text-main placeholder:text-text-dim/30 shadow-inner"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-text-dim uppercase tracking-[0.2em] flex items-center gap-3 ml-1">
                <Lock size={12} className="text-shadow-ai/60" /> Cryptographic Key
              </label>
              <input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-4 text-[13px] font-mono outline-none focus:border-shadow-ai/50 transition-all text-text-main placeholder:text-text-dim/30 shadow-inner"
                required
              />
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-ai/5 border border-red-ai/10 rounded-xl p-4 flex items-center gap-4 text-red-ai text-[11px] font-mono"
              >
                <div className="w-2 h-2 rounded-full bg-red-ai animate-pulse" />
                <span>{error}</span>
              </motion.div>
            )}

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-shadow-ai hover:brightness-110 active:scale-[0.98] transition-all text-white font-black py-5 rounded-xl text-[11px] uppercase tracking-[0.3em] relative overflow-hidden group shadow-2xl shadow-shadow-ai/40 mt-4"
            >
              <span className={cn("flex items-center justify-center gap-3", isLoading && "opacity-0")}>
                {isNewUser ? "INITIATE_SYNC" : "ESTABLISH_LINK"}
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </span>
              
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center">
                   <RefreshCw className="w-5 h-5 animate-spin" />
                </div>
              )}
            </button>
          </form>

          <div className="mt-8 flex flex-col items-center gap-4">
            <button 
              onClick={() => {
                setIsNewUser(!isNewUser);
                setError(null);
              }}
              className="text-[10px] text-text-dim hover:text-shadow-ai transition-colors font-bold uppercase tracking-widest"
            >
              {isNewUser ? "Return to Authorization" : "Enroll New Agent Profile"}
            </button>
            
            <div className="flex items-center gap-3 w-full opacity-30 mt-4">
              <div className="h-px bg-border-main flex-1" />
              <div className="w-1.5 h-1.5 rounded-full bg-border-main" />
              <div className="h-px bg-border-main flex-1" />
            </div>

            <div className="flex gap-4 mt-2">
              <div className="flex flex-col items-center gap-1">
                <Terminal size={14} className="text-text-dim" />
                <span className="text-[8px] font-mono text-text-dim uppercase">Term_Auth</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <ShieldCheck size={14} className="text-text-dim" />
                <span className="text-[8px] font-mono text-text-dim uppercase">Sec_Lock</span>
              </div>
            </div>
          </div>
        </div>
        
        <p className="text-center mt-8 text-[9px] text-text-dim/50 font-mono uppercase tracking-[0.3em]">
          Classified Information // Authorized Access Only
        </p>
      </motion.div>
    </div>
  );
}
