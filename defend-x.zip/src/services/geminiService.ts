import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const BLUE_AI_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    isSensitive: { type: Type.BOOLEAN },
    classification: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List categories: PII, Source Code, Credentials, Financial, Medical, Normal"
    },
    riskScore: { type: Type.NUMBER, description: "0-100" },
    reasoning: { type: Type.STRING },
    maskedContent: { type: Type.STRING, description: "The prompt with sensitive data masked out" },
    action: { 
      type: Type.STRING, 
      enum: ["ALLOW", "MASK", "BLOCK", "ALERT"],
      description: "Recommended security action"
    }
  },
  required: ["isSensitive", "classification", "riskScore", "reasoning", "action"]
};

export const RED_AI_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    attackType: { type: Type.STRING },
    steps: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING } 
    },
    complexity: { type: Type.STRING },
    payload: { type: Type.STRING, description: "Sample adversarial payload" }
  },
  required: ["attackType", "steps", "complexity", "payload"]
};

export const INTELLIGENCE_LAYER_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    attack_type: { type: Type.STRING },
    confidence: { type: Type.NUMBER, description: "Confidence score 0.0 to 1.0" },
    explanation: { type: Type.STRING },
    suggestion: { type: Type.STRING, description: "Automated response suggestion" },
    severity: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH", "CRITICAL"] }
  },
  required: ["attack_type", "confidence", "explanation", "suggestion", "severity"]
};

export async function intelligenceAnalysis(alert: any, context: any[] = []) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `ALERT: ${JSON.stringify(alert)}. HISTORY: ${JSON.stringify(context)}. Analyze this threat and provide a detailed L5 intelligence report.`,
      config: {
        systemInstruction: `You are the "Intelligence Layer" (Layer 5) of a sophisticated SOC. 
        Analyze normalized alerts from Layer 4 and correlated log history. Explain the threat using reasoning, provide a confidence score, and suggest immediate containment actions for the Decision & Response Layer (Layer 6).`,
        responseMimeType: "application/json",
        responseSchema: INTELLIGENCE_LAYER_SCHEMA,
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Intelligence Layer Analysis Error:", error);
    return {
      attack_type: "Unknown",
      confidence: 0,
      explanation: "Analysis failed due to neural timeout.",
      suggestion: "Manual review required.",
      severity: "MEDIUM"
    };
  }
}

export async function analyzePrompt(prompt: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this user prompt for potential data leaks in a Shadow AI context: "${prompt}"`,
      config: {
        systemInstruction: `You are the "Blue AI" data classification engine. 
        Detect PII (emails, phones, addresses), Source Code (internal logic), Credentials (API keys, passwords), Financial (bank info), and Medical data.
        Return a security decision and masked content if needed.`,
        responseMimeType: "application/json",
        responseSchema: BLUE_AI_SCHEMA,
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Blue AI Analysis Error:", error);
    return null;
  }
}

export async function simulateAttack() {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a realistic cyber attack simulation scenario for an enterprise network (e.g., Data Exfiltration, C2 Beaconing).",
      config: {
        systemInstruction: "You are 'Red AI', an adversarial simulation engine. Generate stealthy attack patterns.",
        responseMimeType: "application/json",
        responseSchema: RED_AI_SCHEMA,
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Red AI Simulation Error:", error);
    return null;
  }
}

export async function generateDefensivePlaybook(attackType: string, reasoning: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Attack Type: ${attackType}. Context: ${reasoning}. Generate a SOC defensive playbook.`,
      config: {
        systemInstruction: "You are 'Shadow AI', the autonomous defense engine. Provide step-by-step containment and mitigation steps.",
      },
    });

    return response.text;
  } catch (error) {
    console.error("Shadow AI Playbook Error:", error);
    return "Error generating playbook.";
  }
}
